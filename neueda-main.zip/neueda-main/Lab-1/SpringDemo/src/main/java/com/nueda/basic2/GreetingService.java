package com.nueda.basic2;

public interface GreetingService {
	String greet();
}