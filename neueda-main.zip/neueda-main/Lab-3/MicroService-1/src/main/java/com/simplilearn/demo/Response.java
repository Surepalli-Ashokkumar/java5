package com.simplilearn.demo;

public class Response {

	PersonEntity entity;
	private String hobby;
	public PersonEntity getEntity() {
		return entity;
	}
	public void setEntity(PersonEntity entity) {
		this.entity = entity;
	}
	public String getHobby() {
		return hobby;
	}
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	
	
}
