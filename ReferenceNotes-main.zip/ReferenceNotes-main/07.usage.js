const mymodule= require('./07.custom')

mymodule.printMsg();
mymodule.greeting("sonam")


