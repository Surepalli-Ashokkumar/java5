exports.printMsg = function() {
    console.log("Learning Node.js is awesome!");
  }
exports.greeting = function(name){
    console.log(`Welcome ${name}`)
}

// module.exports={
//     printMsg,
//     greeting
// }

